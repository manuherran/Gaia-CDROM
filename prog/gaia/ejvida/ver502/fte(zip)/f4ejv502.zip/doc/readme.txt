Este fichero es un indice de los modulos que componen el proyecto

Ficheros
========
inicio.txt  Fichero global de configuraci�n
gaia.xls    Ejemplo de llamadas al programa desde Excel
version.doc Documentaci�n
version.txt Documentaci�n
readme.txt  Documentaci�n
*.3r        Proceso de Aprendizaje del tres en raya
*.aut       Configuraci�n espec�fica de un ejemplo autom�tico
*.bmp       Imagenes de semaforos
*.hyp       En obras (no utilizados)
*.ico       Iconos para los *.frm
*.map       Mapas de obst�culos de Vida Artificial
*.pri       Definici�n de jugadores al prisionero
*.ran       Digitos al Azar. Por ejemplo, pi49999.ran son los 49999 primeros decimales del n�mero pi
*.dic       Diccionario. Por ejemplo, 10487.dic posee 10487 palabras
*.log       Informe general de la ejecuci�n autom�tica. Es opcional tanto en modo autom�tico como normal.
*.xls       Puede ser un informe general de una ejecuci�n (autom�tica o normal) o espec�fico de un ejemplo (autom�tico o normal)
*.txt       Puede ser un informe general de una ejecuci�n (autom�tica o normal) o espec�fico de un ejemplo (autom�tico o normal)
*.gra       Gr�fico de la ejecuci�n de un ejemplo, ya sea autom�tico o normal



M�dulos Visual Basic (*.frm, *.frx, *.bas y fwvida42.vbp)
=========================================================

Las letras son agrupaciones de programas que comparten c�digo y variables
La aplicacion no permite ejecutar mas de un tipo de programa a la vez (antes si lo hacia)
a:  Vida artificial: 1 + 4 + 5 + 6 + 7 + 9
b:  Palabras y frases: 2
c:  Computaci�n Evolutiva: 3 + 8
z:  Cosas generales: 0


Los n�meros son los programas que ve el usuario
0:  Cosas generales
1:  Hormigas y Plantas
2:  Palabras y Frases
3:  Tres en Raya
4:  El dilema del prisionero
5:  Celdilla
6:  Plataforma Gaia
7:  Explorando Mapas
8:  Cadenas
9:  Peces

Por tanto tenemos
a0: Cosas generales de Vida Artificial
c0: Cosas generales de Computaci�n Evolutiva
a1: Hormigas y plantas
b2: Palabras y Frases
b2: Palabras y frases
c3: Tres en raya
a4: El dilema del prisionero
a5: Celdilla
a6: Plataforma Gaia
a7: Explorando Mapas
c8: Cadenas
a9: Peces

